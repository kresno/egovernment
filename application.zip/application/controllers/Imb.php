<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Imb extends CI_Controller {
function __construct(){
		parent::__construct();
		$this->load->model('imb_model');

	} 
	
	
	public function index()
	{
		$data = array('title' => 'Izin Mendirikan Bangunan',
                        'Isi' => 'imb');
        $this->load->view('admin/layout/head',$data);
        $this->load->view('header',$data);
        $this->load->view('navuser',$data);
        $this->load->view('imb',$data);
		
	}
	public function nik(){
    	$nik=$this->input->post('nik');
        
    	$cek=$this->imb_model->input_nik($nik);
		if($cek){
			redirect('form_imb/data_user/'.$nik);
		}else{
        echo "<script>alert('Gagal Login, Anda bukan warga kecamatan Bogor Utara.');window.location='index';</script>";exit;
            $this->session->set_flashdata('info','Gagal Login, Anda bukan warga kecamatan Bogor Utara.');
    }
    }
    public function data_user(){
    	$nik=$this->input->post('nik');
    	$data['nik']=$nik;
    	$data['tgl_daftar']=date("Y-m-d");
    	$data['nama_perusahaan']=$this->input->post('nama_perusahaan');
    	$data['jenis_usaha']=$this->input->post('jenis_usaha');
        $data['lokasi_bangunan']=$this->input->post('lokasi_bangunan');
        $data['file_ktp']='ktp'.$nik;
    	$data['file_pbb']='pbb'.$nik;
    	
    	$config['upload_path']		= './uploads/IMB/';
	    $config['allowed_types']	= 'jpg|jpeg|png';
    	$config['max_size']			= 2024;
    	$this->load->library('upload',$config);
        $this->upload->initialize($config);
    	if ($this->upload->do_upload('file_ktp')) {
            $data['file_ktp'] = $this->upload->data('file_name');
        }
    	
    	$config1['upload_path']		= './uploads/IMB/PBB/';
	    $config1['allowed_types']	= 'jpg|jpeg|png';
    	$config1['max_size']		= 2024;
    	$this->load->library('upload',$config1);
    	$this->load->initialize($config1);
    	if ($this->upload->do_upload('file_pbb')) {
            $data['file_pbb'] =  $this->upload->data('file_name');
        }
        
    	
        $tb='simb';
        $this->load->model('imb_model');
        $this->imb_model->tambah_data($data,$tb);
        redirect('form_imb/data_user/'.$nik);
    	}
	

}
