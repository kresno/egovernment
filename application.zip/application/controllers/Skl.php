<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Skl extends CI_Controller {
function __construct(){
		parent::__construct();
		$this->load->model('skl_model');

	} 
	
	
	public function index()
	{
		$data = array('title' => 'Surat Keterangan Lahir');
        $this->load->view('admin/layout/head',$data);
        $this->load->view('header',$data);
        $this->load->view('navuser',$data);
        $this->load->view('skl',$data);
		
	}
	public function nik(){
    	$nik=$this->input->post('nik');
    	$cek=$this->skl_model->input_nik($nik);
		if($cek){
			redirect('form_skl/data_user/'.$nik);
		}else{
        echo "<script>alert('Maaf anda belum terdaftar. Silahkan daftar terlebih dahulu!');window.location='index';</script>";exit;
            $this->session->set_flashdata('info','Maaf anda belum terdaftar. Silahkan daftar terlebih dahulu!');
    }
    }
    public function data_user(){
    	$nik=$this->input->post('nik');
    	$data['nik']=$nik;
    	$data['tgl_daftar']=date("Y-m-d");
    	$data['nama']=$this->input->post('nama');
    	$data['jenis_kelamin']=$this->input->post('jenis_kelamin');
    	$data['tgl_lahir']=$this->input->post('tgl_lahir');
    	$data['kelahiran']=$this->input->post('kelahiran');
    	$data['tempat_lahir']=$this->input->post('tempat_lahir');
    	$data['penolong_kelahiran']=$this->input->post('penolong_kelahiran');
    	$data['nama_ibu']=$this->input->post('nama_ibu');
    	$data['alamat_ibu']=$this->input->post('alamat_ibu');
        $data['lahir_ibu']=$this->input->post('lahir_ibu');
        $data['agama_ibu']=$this->input->post('agama_ibu');
    	$data['nama_ayah']=$this->input->post('nama_ayah');
    	$data['lahir_ayah']=$this->input->post('lahir_ayah');
    	$data['agama_ayah']=$this->input->post('agama_ayah');
    	$data['pekerjaan']=$this->input->post('pekerjaan');
        $data['kewarganegaraan_ayah']=$this->input->post('kewarganegaraan_ayah');
    	$data['no_ktp']=$this->input->post('no_ktp');


        $tb='skl';
        $this->load->model('Skl_model');
        $this->Skl_model->tambah_data($data,$tb);
        redirect('form_skl/data_user/'.$nik);
    	}
	

}
