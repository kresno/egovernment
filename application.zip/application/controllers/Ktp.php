<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ktp extends CI_Controller {

	
	function __construct(){
		parent::__construct();
		$this->load->model('ktp_model');

	} 
	
	public function index()
	{
		$data = array('title' => 'Kecamatan Bogor Utara',
                        'Isi' => 'ktp');
        $this->load->view('admin/layout/head',$data);
        $this->load->view('header',$data);
        $this->load->view('navuser',$data);
        $this->load->view('ktp',$data);
		
	}

    public function nik(){
    	$nik=$this->input->post('nik');
    	$cek=$this->ktp_model->input_nik($nik);
      if($cek){
         redirect('form_ktp/data_user/'.$nik);
     }else{
      echo "<script>alert('Gagal Register, Anda bukan warga kecamatan Bogor Utara.');window.location='index';</script>";exit;
            $this->session->set_flashdata('info','Gagal Register, Anda bukan warga kecamatan Bogor Utara.');
         redirect('ktp');
     }
     $test=$this->ktp_model->error_log($nik);
     if($test){
       redirect('form_ktp/data_user/'.$nik);

   }
   else { echo "gak ada";

}
}

public function data_user(){
   $nik=$this->input->post('nik');
   $data['nik']=$nik;
   $data['tgl_daftar']=date("Y-m-d");
   $data['provinsi']=$this->input->post('provinsi');
   $data['kabupaten']=$this->input->post('kabupaten');
   $data['kelurahan']=$this->input->post('kelurahan');
   $data['kecamatan']=$this->input->post('kecamatan');
   $data['nama']=$this->input->post('nama');
   $data['alamat']=$this->input->post('alamat');
   $data['file_kk']=$this->input->post('file_kk');
   $data['file_foto']='foto'.$nik;
   $data['file_kk']='foto'.$nik;

   $config['upload_path']      = './uploads/KTP/';
   $config['allowed_types']    = 'jpg|jpeg|png';
   $config['max_size']         = 2024;
   $this->load->library('upload',$config);
   $this->upload->initialize($config);
   if ($this->upload->do_upload('file_foto')) {
    $data['file_foto'] = $this->upload->data('file_name');
}
$config1['upload_path']      = './uploads/KTP/';
   $config1['allowed_types']    = 'jpg|jpeg|png';
   $config1['max_size']         = 2024;
   $this->load->library('upload',$config);
   $this->upload->initialize($config);
   if ($this->upload->do_upload('file_kk')) {
    $data['file_kk'] = $this->upload->data('file_name');
}

$tb='ktp';
$this->load->model('ktp_model');
$this->ktp_model->tambah_data($data,$tb);
redirect('form_ktp/data_user/'.$nik);
}


}
