<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sku extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('sku_model');

	} 
	
	
	public function index()
	{
		$data = array('title' => 'Surat Keterangan Usaha');
		$this->load->view('header',$data);
		$this->load->view('navuser',$data);
		$this->load->view('sku',$data);
		
	}
	public function nik(){
    	$nik=$this->input->post('nik');
    	$cek=$this->sku_model->input_nik($nik);
		if($cek){
			redirect('form_sku/data_user/'.$nik);
		}else{
        echo "<script>alert('Maaf anda belum terdaftar. Silahkan daftar terlebih dahulu!');window.location='index';</script>";exit;
            $this->session->set_flashdata('info','Maaf anda belum terdaftar. Silahkan daftar terlebih dahulu!');
    }
    }

    public function data_user(){
    	$nik=$this->input->post('nik');
    	$data['nik']=$nik;
    	$data['tgl_daftar']=date("Y-m-d");
    	$data['nama_perusahaan']=$this->input->post('nama_perusahaan');
    	$data['jenis_usaha']=$this->input->post('jenis_usaha');
		$data['alamat_usaha']=$this->input->post('alamat_usaha');
		$data['file_ktp']='file_ktp.jpg';
		$data['file_pbb']='file_pbb.jpg';

		

    	$config['upload_path']		= './uploads/SKU/';
	    $config['allowed_types']	= 'jpg|jpeg|png';
    	$config['max_size']			= '2024';
    	$this->load->library('upload',$config);
    	{
    		if ($this->upload->do_upload('file_ktp')) {
            $data['file_ktp'] =  $this->upload->data('file_name');
    	}
    
    	$config['upload_path']		= './uploads/SKU/';
	    $config['allowed_types']	= 'jpg|jpeg|png';
    	$config['max_size']			= '2024';
    	$this->load->library('upload',$config);
		{
    		if ($this->upload->do_upload('file_pbb')) {
            $data['file_pbb'] =  $this->upload->data('file_name');
    	}
    		
		$tb='skus';
		$this->load->model('Sku_model');
    	$this->Sku_model->tambah_data($data,$tb);
    	redirect('form_sku/data_user/'.$nik);

    }
}

}
}