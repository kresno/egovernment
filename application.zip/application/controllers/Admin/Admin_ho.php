<?php
defined( 'BASEPATH') OR exit('No direct script access allowed');

class Admin_ho extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('Ho_model');

	} 
	public function index()
	{

		$data = array('title' => 'HO',
						'Isi' => 'admin/admin_sku');
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/admin_ho',$data);
		$this->load->view('admin/layout/footer',$data);
		
		
	}
	public function data_user(){
		$date=$this->input->post('date');
		$data = array('title' => 'HO',
						'Isi' => 'admin/admin_ho');
		$this->load->library('session');
		$username=$this->session->userdata['username'];
		$data['username']=$username;
		if(substr($username,0,2)=='rt'){
		$data['rt']=substr($username,2,3);
		$data['rw']=substr($username,5,3);
		$data['kelurahan']=substr($username,8);
		$tb='siho';
		$this->load->model('Admin_ho_model');
		$data['data_user'] = $this->Admin_ho_model->data_user($tb,$date);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/admin_ho',$data);
		$this->load->view('admin/layout/footer',$data);
		
		}
		else if(substr($username,0,2)=='rw'){
		$data['rw']=substr($username,2,3);
		$data['kelurahan']=substr($username,5);
		$tb='siho';
		$this->load->model('Admin_ho_model');
		$data['data_user'] = $this->Admin_ho_model->data_user($tb,$date);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasi_ho_rw',$data);
		$this->load->view('admin/layout/footer',$data);
		}
		else if(substr($username,0)=='admin'){ 
		$data['admin']=substr($username,5);
		$tb='siho';
		$this->load->model('Admin_ho_model');
		$data['data_user'] = $this->Admin_ho_model->data_user($tb,$date);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasi_ho_camat',$data);
		$this->load->view('admin/layout/footer',$data);
		$this->load->view('admin/layout/footer',$data);
		
		}
		else{
		$data['kelurahan']=substr($username,0);

		$tb='siho';
		$this->load->model('Admin_ho_model');
		$data['data_user'] = $this->Admin_ho_model->data_user($tb,$date);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasi_ho_lurah',$data);
		$this->load->view('admin/layout/footer',$data);
		
		}
	}

	public function lihat(){
		$data = array('title' => 'ho',
						'Isi' => 'admin/admin_ho');
		$id_ho=$this->uri->segment(4);
		$tb='siho';
		$this->load->model('ho_model');
		$data['data'] = $this->ho_model->lihat($id_ho,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/lihat_ho',$data);
		$this->load->view('admin/layout/footer',$data);
	
		
	}

	public function delete(){
		$id_ho=$this->uri->segment(4);
		$tb='siho';
		$this->load->model('ho_model');
		$this->ho_model->deletedata($id_ho,$tb);
		redirect('Admin/Admin_ho/data_user');
	}
	

	public function legalisasi(){
		$data = array('title' => 'ho',
						'Isi' => 'admin/admin_ho');
		$id_ho=$this->uri->segment(4);
		$tb='siho';
		$this->load->model('ho_model');
		$data['tgl_rt']=date("Y-m-d");
		$data['data'] = $this->ho_model->lihat($id_ho,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasiho',$data);
	}
	public function legalisasirw(){
		$data = array('title' => 'ho',
						'Isi' => 'admin/admin_ho');
		$id_ho=$this->uri->segment(4);
		$tb='siho';
		$this->load->model('ho_model');
		$data['tgl_rw']=date("Y-m-d");
		$data['data'] = $this->ho_model->lihat($id_ho,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasihorw',$data);
	}
	public function legalisasilurah(){
		$data = array('title' => 'ho',
						'Isi' => 'admin/admin_ho');
		$id_ho=$this->uri->segment(4);
		$tb='siho';
		$this->load->model('ho_model');
		$data['tgl_lurah']=date("Y-m-d");
		$data['data'] = $this->ho_model->lihat($id_ho,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasiholurah',$data);
	}
	public function legalisasicamat(){
		$data = array('title' => 'ho',
						'Isi' => 'admin/admin_ho');
		$id_ho=$this->uri->segment(4);
		$tb='siho';
		$this->load->model('ho_model');
		$data['tgl_camat']=date("Y-m-d");
		$data['data'] = $this->ho_model->lihat($id_ho,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasihocamat',$data);
	}
	}
