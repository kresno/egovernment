<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edit_sktt extends CI_Controller {


	public function index()
	{

		$data = array('title' => 'SKTT');
		
		$id_sktt=$this->uri->segment(4);
		$tb='sktt';
		$this->load->model('Sktt_model');
		$data['data']=$this->Sktt_model->getdata($id_sktt,$tb);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/edit_sktt',$data);
		
	}

public function update()
	{
		$id_sktts=$this->input->post('id_sktt');
		$data['id_sktt']=$this->input->post('id_sktt');
		$data['tgl_daftar']=$this->input->post('tgl_daftar');
		$data['nik']=$this->input->post('nik');
		$data['tgl_rt']=$this->input->post('tgl_rt');
		$data['tgl_rw']=$this->input->post('tgl_rw');
		$data['tgl_lurah']=$this->input->post('tgl_lurah');
		$data['tgl_camat']=$this->input->post('tgl_camat');
		$data['pekerjaan']=$this->input->post('pekerjaan');
		$data['alamat']=$this->input->post('alamat');
		$data['file_ktp']=$this->input->post('file_ktp');
		$data['file_kk']=$this->input->post('file_kk');
		
		$tb='sktt';
		$this->load->model('sktt_model');
		$this->sktt_model->editdata($id_sktt,$tb,$data);
		redirect('Admin/Admin_sktt/data_user');
	}


public function updatelegal()
{
	$id_sktt=$this->input->post('id_sktt');
	$data['id_sktt']=$this->input->post('id_sktt');
	$data['legalisasi_rt']=$this->input->post('legalisasi_rt');
	$data['tgl_rt']=date("Y-m-d");
	$tb='sktt';
		$this->load->model('sktt_model');
		$this->sktt_model->editdata($id_sktt,$tb,$data);
		redirect('Admin/Admin_sktt/data_user');
}
public function updatelegalrw()
{
	$id_sktt=$this->input->post('id_sktt');
	$data['id_sktt']=$this->input->post('id_sktt');
	$data['legalisasi_rw']=$this->input->post('legalisasi_rw');
	$data['tgl_rw']=date("Y-m-d");

	$tb='sktt';
		$this->load->model('sktt_model');
		$this->sktt_model->editdata($id_sktt,$tb,$data);
		redirect('Admin/Admin_sktt/data_user');
}
public function updatelegallurah()
{
	$id_sktt=$this->input->post('id_sktt');
	$data['id_sktt']=$this->input->post('id_sktt');
	$data['legalisasi_lurah']=$this->input->post('legalisasi_lurah');
	$data['tgl_lurah']=date("Y-m-d");
	$tb='sktt';
		$this->load->model('sktt_model');
		$this->sktt_model->editdata($id_sktt,$tb,$data);
		redirect('Admin/Admin_sktt/data_user');
}
public function updatelegalcamat()
{
	$id_sktt=$this->input->post('id_sktt');
	$data['id_sktt']=$this->input->post('id_sktt');
	$data['legalisasi_camat']=$this->input->post('legalisasi_camat');
	$data['tgl_camat']=date("Y-m-d");
	$tb='sktt';
		$this->load->model('sktt_model');
		$this->sktt_model->editdata($id_sktt,$tb,$data);
		redirect('Admin/Admin_sktt/data_user');
}


}
