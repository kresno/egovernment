<?php
defined( 'BASEPATH') OR exit('No direct script access allowed');

class Admin_sku extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('admin_sku_model');

	} 
	public function index()
	{

		$data = array('title' => 'SKU',
						'Isi' => 'admin/admin_sku');
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/admin_sku',$data);
		
		
	}
	public function data_user(){
		$date=$this->input->post('date');
		$data = array('title' => 'SKU',
						'Isi' => 'admin/admin_sku');
		$this->load->library('session');
		$username=$this->session->userdata['username'];
		$data['username']=$username;
		if(substr($username,0,2)=='rt'){
		$data['rt']=substr($username,2,3);
		$data['rw']=substr($username,5,3);
		$data['kelurahan']=substr($username,8);
		$tb='skus';
		$this->load->model('Admin_sku_model');
		$data['data_user'] = $this->Admin_sku_model->data_user($tb,$date);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/admin_sku',$data);
		$this->load->view('admin/layout/footer',$data);
		
		}
		else if(substr($username,0,2)=='rw'){
		$data['rw']=substr($username,2,3);
		$data['kelurahan']=substr($username,5);
		$tb='skus';
		$this->load->model('Admin_sku_model');
		$data['data_user'] = $this->Admin_sku_model->data_user($tb,$date);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasi_sku_rw',$data);
		$this->load->view('admin/layout/footer',$data);
		
		}
		else if(substr($username,0)=='admin'){ 
		$data['admin']=substr($username,5);
		$tb='skus';
		$this->load->model('Admin_sku_model');
		$data['data_user'] = $this->Admin_sku_model->data_user($tb,$date);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasi_sku_camat',$data);
		$this->load->view('admin/layout/footer',$data);
		}
		else{
		$data['kelurahan']=substr($username,0);
		$tb='skus';
		$this->load->model('Admin_sku_model');
		$data['data_user'] = $this->Admin_sku_model->data_user($tb,$date);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasi_sku_lurah',$data);
		$this->load->view('admin/layout/footer',$data);
		}	
	}

	public function lihat(){
		$data = array('title' => 'SKU',
						'Isi' => 'admin/admin_sku');
		$id_skus=$this->uri->segment(4);
		$tb='skus';
		$this->load->model('Sku_model');
		$data['data'] = $this->Sku_model->lihat($id_skus,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/lihat_sku',$data);
		$this->load->view('admin/layout/footer',$data);
			
	}

		public function delete(){
			$id_skus=$this->uri->segment(4);
			$tb='skus';
			$this->load->model('Sku_model');
			$this->Sku_model->deletedata($id_skus,$tb);
			redirect('Admin/Admin_sku/data_user');
		}

	public function legalisasi(){
		$data = array('title' => 'SKU',
						'Isi' => 'admin/admin_sku');
		$id_skus=$this->uri->segment(4);
		$tb='skus';
		$this->load->model('Sku_model');
		$data['data'] = $this->Sku_model->lihat($id_skus,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasisku',$data);
		$this->load->view('admin/layout/footer',$data);
	}
public function legalisasirw(){
		$data = array('title' => 'SKU',
						'Isi' => 'admin/admin_sku');
		$id_skus=$this->uri->segment(4);
		$tb='skus';
		$this->load->model('Sku_model');
		$data['data'] = $this->Sku_model->lihat($id_skus,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasiskurw',$data);
		$this->load->view('admin/layout/footer',$data);
	}
	public function legalisasilurah(){
		$data = array('title' => 'SKU',
						'Isi' => 'admin/admin_sku');
		$id_skus=$this->uri->segment(4);
		$tb='skus';
		$this->load->model('Sku_model');
		$data['data'] = $this->Sku_model->lihat($id_skus,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasiskulurah',$data);
		$this->load->view('admin/layout/footer',$data);
	}
	public function legalisasicamat(){
		$data = array('title' => 'SKU',
						'Isi' => 'admin/admin_sku');
		$id_skus=$this->uri->segment(4);
		$tb='skus';
		$this->load->model('Sku_model');
		$data['data'] = $this->Sku_model->lihat($id_skus,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasiskucamat',$data);
		$this->load->view('admin/layout/footer',$data);
	}
	}
