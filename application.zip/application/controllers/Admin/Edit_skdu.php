<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edit_skdu extends CI_Controller {


	public function index()
	{

		$data = array('title' => 'SKDU');
		
		$id_skdu=$this->uri->segment(4);
		$tb='skdu';
		$this->load->model('Skdu_model');
		$data['data']=$this->Skdu_model->getdata($id_skdu,$tb);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/edit_skdu',$data);
		$this->load->view('admin/layout/footer',$data);
		
	}

public function update()
	{
		$id_skdu=$this->input->post('id_skdu');
		$data['id_skdu']=$this->input->post('id_skdu');
		$data['tgl_daftar']=$this->input->post('tgl_daftar');
		$data['nik']=$this->input->post('nik');
		$data['nama_perusahaan']=$this->input->post('nama_perusahaan');
		$data['jenis_usaha']=$this->input->post('jenis_usaha');
		$data['akta_perusahaan']=$this->input->post('akta_perusahaan');
		$data['status_tempat']=$this->input->post('status_tempat');
		$data['luas_tempat']=$this->input->post('luas_tempat');
		$data['alamat_usaha']=$this->input->post('alamat_usaha');
		$data['jumlah_tenaga']=$this->input->post('jumlah_tenaga');
		$data['file_ktp']='ktp'.$nik;
    	$data['file_kk']='kk'.$nik;
    	$data['file_akte']='akte'.$nik;
    	$data['file_pbb']='pbb'.$nik;
    	
        $config['upload_path']     = './uploads/SKDU/';
        $config['allowed_types']   = 'jpg|jpeg|png';
        $config['max_size']        = 2024;
        $this->load->library('upload',$config);
        $this->load->initialize($config);
        if ($this->upload->do_upload('file_pbb')) {
            $data['file_pbb'] =  $this->upload->data('file_name');
        }

        $config1['upload_path']     = './uploads/SKDU/';
        $config1['allowed_types']   = 'jpg|jpeg|png';
        $config1['max_size']        = 2024;
        $this->load->library('upload',$config1);
        $this->load->initialize($config1);
        if ($this->upload->do_upload('file_akte')) {
            $data['file_akte'] =  $this->upload->data('file_name');
        }



        $config2['upload_path']     = './uploads/SKDU/';
        $config2['allowed_types']   = 'jpg|jpeg|png';
        $config2['max_size']        = 2024;
        $this->load->library('upload',$config2);
        $this->load->initialize($config2);
        if ($this->upload->do_upload('file_kk')) {
            $data['file_kk'] =  $this->upload->data('file_name');
        }

    	$config3['upload_path']		= './uploads/SKDU/';
	    $config3['allowed_types']	= 'jpg|jpeg|png';
    	$config3['max_size']			= 2024;
    	$this->load->library('upload',$config3);
        $this->upload->initialize($config3);
    	if ($this->upload->do_upload('file_ktp')) {
            $data['file_ktp'] = $this->upload->data('file_name');
        }
    	
		
		$tb='skdu';
		$this->load->model('Skdu_model');
		$this->Skdu_model->editdata($id_skdu,$tb,$data);
		redirect('Admin/Admin_skdu/data_user');
	}


public function updatelegal()
{
	$id_skdu=$this->input->post('id_skdu');
	$data['id_skdu']=$this->input->post('id_skdu');
	$data['legalisasi_rt']=$this->input->post('legalisasi_rt');
	$data['tgl_rt']=date("Y-m-d");

	$tb='skdu';
		$this->load->model('skdu_model');
		$this->skdu_model->editdata($id_skdu,$tb,$data);
		redirect('Admin/Admin_skdu/data_user');
}
public function updatelegalrw()
{
	$id_skdu=$this->input->post('id_skdu');
	$data['id_skdu']=$this->input->post('id_skdu');
	$data['legalisasi_rw']=$this->input->post('legalisasi_rw');
	$data['tgl_rw']=date("Y-m-d");


	$tb='skdu';
		$this->load->model('Skdu_model');
		$this->Skdu_model->editdata($id_skdu,$tb,$data);
		redirect('Admin/Admin_skdu/data_user');
}
public function updatelegallurah()
{
	$id_skdu=$this->input->post('id_skdu');
	$data['id_skdu']=$this->input->post('id_skdu');
	$data['legalisasi_lurah']=$this->input->post('legalisasi_lurah');
	$data['tgl_lurah']=date("Y-m-d");


	$tb='skdu';
		$this->load->model('Skdu_model');
		$this->Skdu_model->editdata($id_skdu,$tb,$data);
		redirect('Admin/Admin_skdu/data_user');
}
public function updatelegalcamat()
{
	$id_skdu=$this->input->post('id_skdu');
	$data['id_skdu']=$this->input->post('id_skdu');
	$data['legalisasi_camat']=$this->input->post('legalisasi_camat');
	$data['tgl_camat']=date("Y-m-d");


	$tb='skdu';
		$this->load->model('Skdu_model');
		$this->Skdu_model->editdata($id_skdu,$tb,$data);
		redirect('Admin/Admin_skdu/data_user');
}


}
