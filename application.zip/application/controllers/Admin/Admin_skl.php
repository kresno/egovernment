<?php
defined( 'BASEPATH') OR exit('No direct script access allowed');

class Admin_skl extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('skl_model');

	} 

	public function index(){
		$data = array('title' => 'SKL',
			'Isi' => 'admin/admin_skl');
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/admin_skl',$data);	
		$this->load->view('admin/layout/footer',$data);
	}
	public function data_user(){
		$date=$this->input->post('date');
		$data = array('title' => 'SKL',
			'Isi' => 'admin/admin_skl');
		$this->load->library('session');
		$username=$this->session->userdata['username'];
		$data['username']=$username;
		if(substr($username,0,2)=='rt'){
			$data['rt']=substr($username,2,3);
			$data['rw']=substr($username,5,3);
			$data['kelurahan']=substr($username,8);
			$tb='skl';
			$this->load->model('Admin_skl_model');
			$data['data_user'] = $this->Admin_skl_model->data_user($tb,$date);
			$this->load->view('admin/layout/head',$data);
			$this->load->view('admin/layout/header',$data);
			$this->load->view('admin/layout/nav',$data);
			$this->load->view('admin/admin_skl',$data);
			$this->load->view('admin/layout/footer',$data);

		}
		else if(substr($username,0,2)=='rw'){
			$data['rw']=substr($username,2,3);
			$data['kelurahan']=substr($username,5);
			$tb='skl';
			$this->load->model('Admin_skl_model');
			$data['data_user'] = $this->Admin_skl_model->data_user($tb,$date);
			$this->load->view('admin/layout/head',$data);
			$this->load->view('admin/layout/header',$data);
			$this->load->view('admin/layout/nav',$data);
			$this->load->view('admin/legalisasi_skl_rw',$data);
			$this->load->view('admin/layout/footer',$data);

		}
		else if(substr($username,0)=='admin'){ 
			$data['admin']=substr($username,5);
			$tb='skl';
			$this->load->model('Admin_skl_model');
			$data['data_user'] = $this->Admin_skl_model->data_user($tb,$date);
			$this->load->view('admin/layout/head',$data);
			$this->load->view('admin/layout/header',$data);
			$this->load->view('admin/layout/nav',$data);
			$this->load->view('admin/legalisasi_skl_camat',$data);
			$this->load->view('admin/layout/footer',$data);

		}
		else{
			$data['kelurahan']=substr($username,0);

			$tb='skl';
			$this->load->model('Admin_skl_model');
			$data['data_user'] = $this->Admin_skl_model->data_user($tb,$date);
			$this->load->view('admin/layout/head',$data);
			$this->load->view('admin/layout/header',$data);
			$this->load->view('admin/layout/nav',$data);
			$this->load->view('admin/legalisasi_skl_lurah',$data);
			$this->load->view('admin/layout/footer',$data);
		}
	}

	public function delete(){
		$id_skl=$this->uri->segment(4);
		$tb='skl';
		$this->load->model('Skl_model');
		$this->Skl_model->deletedata($id_skl,$tb);
		redirect('Admin/Admin_skl/data_user');
	}

	public function lihat(){
		$data = array('title' => 'SKL',
			'Isi' => 'admin/admin_skl');
		$id_skl=$this->uri->segment(4);
		$tb='skl';
		$this->load->model('Skl_model');
		$data['data'] = $this->Skl_model->lihat($id_skl,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/lihat_skl',$data);
	}

	public function legalisasi(){
		$data = array('title' => 'SKL',
			'Isi' => 'admin/admin_skl');
		$id_skl=$this->uri->segment(4);
		$tb='skl';
		$this->load->model('skl_model');
		$data['data'] = $this->skl_model->lihat($id_skl,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasiskl',$data);
	}
	public function legalisasirw(){
		$data = array('title' => 'SKL',
			'Isi' => 'admin/admin_skl');
		$id_skl=$this->uri->segment(4);
		$tb='skl';
		$this->load->model('skl_model');
		$data['data'] = $this->skl_model->lihat($id_skl,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasisklrw',$data);
	}
	public function legalisasilurah(){
		$data = array('title' => 'SKL',
			'Isi' => 'admin/admin_skl');
		$id_skl=$this->uri->segment(4);
		$tb='skl';
		$this->load->model('skl_model');
		$data['data'] = $this->skl_model->lihat($id_skl,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasiskllurah',$data);
	}
	public function legalisasicamat(){
		$data = array('title' => 'SKL',
			'Isi' => 'admin/admin_skl');
		$id_skl=$this->uri->segment(4);
		$tb='skl';
		$this->load->model('skl_model');
		$data['data'] = $this->skl_model->lihat($id_skl,$tb);

		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/legalisasisklcamat',$data);
	}


}
