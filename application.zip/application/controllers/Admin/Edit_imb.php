<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edit_imb extends CI_Controller {


	public function index()
	{

		$data = array('title' => 'IMB');
		
		$id_imb=$this->uri->segment(4);
		$tb='simb';
		$this->load->model('imb_model');
		$data['data']=$this->imb_model->getdata($id_imb,$tb);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/edit_imb',$data);
		
	}

public function update()
	{
		$id_simb=$this->input->post('id_simb');
		$data['id_simb']=$this->input->post('id_simb');
		$data['tgl_daftar']=$this->input->post('tgl_daftar');
		$data['nik']=$this->input->post('nik');
		$data['tgl_rt']=$this->input->post('tgl_rt');
		$data['tgl_rw']=$this->input->post('tgl_rw');
		$data['tgl_lurah']=$this->input->post('tgl_lurah');
		$data['tgl_daftar']=$this->input->post('tgl_daftar');
		$data['tgl_camat']=$this->input->post('tgl_camat');
		$data['nama_perusahaan']=$this->input->post('nama_perusahaan');
		$data['jenis_usaha']=$this->input->post('jenis_usaha');
		$data['lokasi_bangunan']=$this->input->post('lokasi_bangunan');
		$data['file_ktp']=$this->input->post('file_ktp');
		$data['file_pbb']=$this->input->post('file_pbb');
		
		$tb='simb';
		$this->load->model('imb_model');
		$this->imb_model->editdata($id_simb,$tb,$data);
		redirect('Admin/Admin_imb/data_user');
	}

public function updatelegal()
{
	$id_simb=$this->input->post('id_simb');
	//$data['id_simb']=$this->input->post('id_simb');
	$data['legalisasi_rt']=$this->input->post('legalisasi_rt');
	$data['tgl_rt']=date("Y-m-d");
	$tb='simb';
		$this->load->model('imb_model');
		$this->imb_model->editdata($id_simb,$tb,$data);
		redirect('Admin/Admin_imb/data_user');
}
public function updatelegalrw()
{
	$id_simb=$this->input->post('id_simb');
	$data['id_simb']=$this->input->post('id_simb');
	$data['legalisasi_rw']=$this->input->post('legalisasi_rw');
	$data['tgl_rt']=date("Y-m-d");

	$tb='simb';
		$this->load->model('imb_model');
		$this->imb_model->editdata($id_simb,$tb,$data);
		redirect('Admin/Admin_imb/data_user');
}
public function updatelegallurah()
{
	$id_simb=$this->input->post('id_simb');
	$data['id_simb']=$this->input->post('id_simb');
	$data['legalisasi_lurah']=$this->input->post('legalisasi_lurah');
	$data['tgl_rt']=date("Y-m-d");

	$tb='simb';
		$this->load->model('imb_model');
		$this->imb_model->editdata($id_simb,$tb,$data);
		redirect('Admin/Admin_imb/data_user');
}
public function updatelegalcamat()
{
	$id_simb=$this->input->post('id_simb');
	$data['id_simb']=$this->input->post('id_simb');
	$data['legalisasi_camat']=$this->input->post('legalisasi_camat');
	$data['tgl_rt']=date("Y-m-d");

	$tb='simb';
		$this->load->model('imb_model');
		$this->imb_model->editdata($id_simb,$tb,$data);
		redirect('Admin/Admin_imb/data_user');
}


}
