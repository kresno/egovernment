<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edit_ktp extends CI_Controller {


	public function index()
	{

		$data = array('title' => 'ktp');
		
		$id_ktp=$this->uri->segment(4);
		$tb='ktp';
		$this->load->model('ktp_model');
		$data['data']=$this->ktp_model->getdata($id_ktp,$tb);
		$this->load->view('admin/layout/head',$data);
		$this->load->view('admin/layout/header',$data);
		$this->load->view('admin/layout/nav',$data);
		$this->load->view('admin/edit_ktp',$data);
}

public function update()
	{
		$id_ktp=$this->input->post('id_ktp');
		$data['tgl_daftar']=$this->input->post('tgl_daftar');
		$data['provinsi']=$this->input->post('provinsi');
		$data['kabupaten']=$this->input->post('kabupaten');
		$data['kecamatan']=$this->input->post('kecamatan');
		$data['kelurahan']=$this->input->post('kelurahan');
		$data['nama']=$this->input->post('nama');
		$data['permohonan_ktp']=$this->input->post('permohonan_ktp');
		$data['file_foto']=$this->input->post('file_foto');
		$data['file_kk']=$this->input->post('file_kk');
		$tb='ktp';
		$this->load->model('ktp_model');
		$this->ktp_model->editdata($id_ktp,$tb,$data);
		redirect('Admin/Admin_ktp/data_user');
	}


public function updatelegal()
{
	$id_ktp=$this->input->post('id_ktp');
	$data['id_ktp']=$this->input->post('id_ktp');
	$data['legalisasi_rt']=$this->input->post('legalisasi_rt');
	$data['tgl_rt']=date("Y-m-d");

	$tb='ktp';
		$this->load->model('ktp_model');
		$this->ktp_model->editdata($id_ktp,$tb,$data);
		redirect('Admin/Admin_ktp/data_user');
}
public function updatelegalrw()
{
	$id_ktp=$this->input->post('id_ktp');
	$data['id_ktp']=$this->input->post('id_ktp');
	$data['legalisasi_rw']=$this->input->post('legalisasi_rw');
	$data['tgl_rt']=date("Y-m-d");
	

	$tb='ktp';
		$this->load->model('ktp_model');
		$this->ktp_model->editdata($id_ktp,$tb,$data);
		redirect('Admin/Admin_ktp/data_user');
}
public function updatelegallurah()
{
	$id_ktp=$this->input->post('id_ktp');
	$data['id_ktp']=$this->input->post('id_ktp');
	$data['legalisasi_lurah']=$this->input->post('legalisasi_lurah');
	$data['tgl_rt']=date("Y-m-d");
	

	$tb='ktp';
		$this->load->model('ktp_model');
		$this->ktp_model->editdata($id_ktp,$tb,$data);
		redirect('Admin/Admin_ktp/data_user');
}
public function updatelegalcamat()
{
	$id_ktp=$this->input->post('id_ktp');
	$data['id_ktp']=$this->input->post('id_ktp');
	$data['legalisasi_camat']=$this->input->post('legalisasi_camat');
	$data['tgl_rt']=date("Y-m-d");
	

	$tb='ktp';
		$this->load->model('ktp_model');
		$this->ktp_model->editdata($id_ktp,$tb,$data);
		redirect('Admin/Admin_ktp/data_user');
}


}
