<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Skdu extends CI_Controller {

	
	function __construct(){
		parent::__construct();
		$this->load->model('skdu_model');

	} 
	
	public function index()
	{
        $data = array('title' => 'Surat Keterangan Domisili Usaha',
                        'Isi' => 'pelayanan');
        $this->load->view('admin/layout/head',$data);
        $this->load->view('headeruser',$data);
        $this->load->view('navuser',$data);
        $this->load->view('skdu',$data);
		
	}
    
    public function nik(){
    	$nik=$this->input->post('nik');

        $this->load->model('skdu_model');
    	$cek=$this->skdu_model->input_nik($nik);
		if($cek){
			redirect('form_skdu/data_user/'.$nik);
		}else{
        echo "<script>alert('Gagal Register, Anda bukan warga kecamatan Bogor Utara.');window.location='index';</script>";exit;
            $this->session->set_flashdata('info','Gagal Register, Anda bukan warga kecamatan Bogor Utara.');
            redirect('skdu');
    }
		$test=$this->skdu_model->error_log($nik);
		if($test){
			 redirect('form_skdu/data_user/'.$nik);

		}
	
    }

    public function data_user(){
    	$nik=$this->input->post('nik');
    	$data['nik']=$nik;
    	$data['tgl_daftar']=date("Y-m-d");
    	$data['nama_perusahaan']=$this->input->post('nama_perusahaan');
    	$data['penanggung_jawab']=$this->input->post('penanggung_jawab');
    	$data['npwp']=$this->input->post('npwp');
    	$data['akta_perusahaan']=$this->input->post('akta_perusahaan');
    	$data['status_tempat']=$this->input->post('status_tempat');
    	$data['luas_tempat']=$this->input->post('luas_tempat');
    	$data['jumlah_tenaga']=$this->input->post('jumlah_tenaga');
    	$data['alamat_usaha']=$this->input->post('alamat_usaha');
        $data['jenis_usaha']=$this->input->post('jenis_usaha');
    	$data['file_ktp']='ktp'.$nik;
    	$data['file_kk']='kk'.$nik;
    	$data['file_akte']='akte'.$nik;
    	$data['file_pbb']='pbb'.$nik;
    	
        $config['upload_path']     = './uploads/SKDU/';
        $config['allowed_types']   = 'jpg|jpeg|png';
        $config['max_size']        = 2024;
        $this->load->library('upload',$config);
        $this->load->initialize($config);
        if ($this->upload->do_upload('file_pbb')) {
            $data['file_pbb'] =  $this->upload->data('file_name');
        }

        $config1['upload_path']     = './uploads/SKDU/';
        $config1['allowed_types']   = 'jpg|jpeg|png';
        $config1['max_size']        = 2024;
        $this->load->library('upload',$config1);
        $this->load->initialize($config1);
        if ($this->upload->do_upload('file_akte')) {
            $data['file_akte'] =  $this->upload->data('file_name');
        }



        $config2['upload_path']     = './uploads/SKDU/';
        $config2['allowed_types']   = 'jpg|jpeg|png';
        $config2['max_size']        = 2024;
        $this->load->library('upload',$config2);
        $this->load->initialize($config2);
        if ($this->upload->do_upload('file_kk')) {
            $data['file_kk'] =  $this->upload->data('file_name');
        }

    	$config3['upload_path']		= './uploads/SKDU/';
	    $config3['allowed_types']	= 'jpg|jpeg|png';
    	$config3['max_size']			= 2024;
    	$this->load->library('upload',$config3);
        $this->upload->initialize($config3);
    	if ($this->upload->do_upload('file_ktp')) {
            $data['file_ktp'] = $this->upload->data('file_name');
        }
    	

        $tb='skdu';
        $this->load->model('Skdu_model');
        $this->Skdu_model->tambah_data($data,$tb);
		redirect('form_skdu/data_user/'.$nik);
		}
}
	


