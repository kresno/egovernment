<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sktt extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('sktt_model');

	} 
	
	
	public function index()
	{
		$data = array('title' => 'Surat Keterangan Tempat Tinggal');
        $this->load->view('admin/layout/head',$data);
        $this->load->view('header',$data);
        $this->load->view('navuser',$data);
        $this->load->view('sktt',$data);
		
	}
	public function nik(){
    	$nik=$this->input->post('nik');
    	$cek=$this->sktt_model->input_nik($nik);
		if($cek){
			redirect('form_sktt/data_user/'.$nik);
		}else{
        echo "<script>alert('Maaf anda belum terdaftar. Silahkan daftar terlebih dahulu!');window.location='index';</script>";exit;
            $this->session->set_flashdata('info','Maaf anda belum terdaftar. Silahkan daftar terlebih dahulu!');
    }
    }
    
    public function data_user(){
    	$nik=$this->input->post('nik');
    	$data['nik']=$nik;
    	$data['tgl_daftar']=date("Y-m-d");    
    	$data['file_pasfoto']='file_pasfoto';
    	$data['file_ktp']='file_ktp';
    	$data['file_kk']='file_kk';	

    	

    	$config1['upload_path']		= './uploads/SKDU/KK/';
	    $config1['allowed_types']	= 'jpg|jpeg|png';
    	$config1['max_size']		= '2024';
    	$this->load->library('upload',$config1);
    	$this->load->initialize($config1);
    	$this->upload->do_upload('file_pasfoto');

    	$config1['upload_path']		= './uploads/SKDU/KK/';
	    $config1['allowed_types']	= 'jpg|jpeg|png';
    	$config1['max_size']		= '2024';
    	$this->load->library('upload',$config1);
    	$this->load->initialize($config1);
        {
            if ($this->upload->do_upload('file_ktp')) {
            $data['file_ktp'] =  $this->upload->data('file_name');
        }
    	

    	$config1['upload_path']		= './uploads/SKDU/KK/';
	    $config1['allowed_types']	= 'jpg|jpeg|png';
    	$config1['max_size']		= '2024';
    	$this->load->library('upload',$config1);
    	$this->load->initialize($config1);
        {
            if ($this->upload->do_upload('file_kk')) {
            $data['file_kk'] =  $this->upload->data('file_name');
        }

        $tb='sktt';
        $this->load->model('Sktt_model');
        $this->Sktt_model->tambah_data($data,$tb);
        redirect('form_sktt/data_user/'.$nik);
    }
}
}}