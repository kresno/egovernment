 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Skk extends CI_Controller {
	
function __construct(){
		parent::__construct();
		$this->load->model('skk_model');

	} 
	
	
	public function index()
	{
		$data = array('title' => 'Surat Keterangan Kematian');
        $this->load->view('admin/layout/head',$data);
        $this->load->view('header',$data);
        $this->load->view('navuser',$data);
        $this->load->view('skk',$data);
		
	}
	public function nik(){
    	$nik=$this->input->post('nik');
    	$cek=$this->skk_model->input_nik($nik);
		if($cek){
			redirect('form_skk/data_user/'.$nik);
		}else{
        echo "<script>alert('Maaf anda belum terdaftar. Silahkan daftar terlebih dahulu!');window.location='index';</script>";exit;
            $this->session->set_flashdata('info','Maaf anda belum terdaftar. Silahkan daftar terlebih dahulu!');
    }
		 
	
    }
    public function data_user(){
    	$nik=$this->input->post('nik');
    	$data['nik']=$nik;
    	$data['tgl_daftar']=date("Y-m-d");
    	$data['nama']=$this->input->post('nama');
    	$data['jenis_kelamin']=$this->input->post('jenis_kelamin');
    	$data['tgl_lahir']=$this->input->post('tgl_lahir');
    	$data['kewarganegaraan']=$this->input->post('kewarganegaraan');
    	$data['agama']=$this->input->post('agama');
    	$data['tempat_lahir']=$this->input->post('tempat_lahir');
    	$data['tgl_meninggal']=$this->input->post('tgl_meninggal');
    	$data['sebab_meninggal']=$this->input->post('sebab_meninggal');
    	$data['tempat_meninggal']=$this->input->post('tempat_meninggal');
    	$data['nama_saudara']=$this->input->post('nama_saudara');
    	$data['umur_saudara']=$this->input->post('umur_saudara');
    	$data['kewarganegaraan_saudara']=$this->input->post('kewarganegaraan_saudara');
    	$data['pekerjaan']=$this->input->post('pekerjaan');
        $data['alamat_saudara']=$this->input->post('alamat_saudara');
    	
    	$tb='skk';
        $this->load->model('Skk_model');
        $this->Skk_model->tambah_data($data,$tb);
        redirect('form_skk/data_user/'.$nik);
		}
   

}
