<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ho extends CI_Controller {
function __construct(){
		parent::__construct();
		$this->load->model('ho_model');

	} 
	
	
	public function index()
	{
		$data = array('title' => 'Hidder Ordonantie',
                        'Isi' => 'ho');
        $this->load->view('admin/layout/head',$data);
        $this->load->view('header',$data);
        $this->load->view('navuser',$data);
        $this->load->view('ho',$data);
		
	}
	public function nik(){
    	$nik=$this->input->post('nik');
    	$cek=$this->ho_model->input_nik($nik);
		if($cek){
			redirect('form_ho/data_user/'.$nik);
		}else{
        echo "<script>alert('Gagal Login, Anda bukan warga kecamatan Bogor Utara.');window.location='index';</script>";exit;
            $this->session->set_flashdata('info','Gagal Login, Anda bukan warga kecamatan Bogor Utara.');
    }
    }
	public function data_user(){
    	$nik=$this->input->post('nik');
    	$data['nik']=$nik;
    	$data['tgl_daftar']=date("Y-m-d");
    	$data['nama_yayasan']=$this->input->post('nama_yayasan');
    	$data['akta_pendirian_yayasan']=$this->input->post('akta_pendirian_yayasan');
        $data['file_ktp']='ktp'.$nik;
        $data['file_akte']='akte'.$nik;
        $data['file_bukti_tanah']='bukti_tanah'.$nik;
        $data['file_imb']='imb'.$nik;
        $data['file_sppl']='sppl'.$nik;
    	$data['file_skdu']='skdu'.$nik;
    	$data['foto_denah']='denah'.$nik;
        $data['foto_depan']='depan'.$nik;
    	$data['file_persetujuan']='persetujuan'.$nik;  
    	$data['file_pbb']='pbb'.$nik;
    	
    	$config['upload_path']		= './uploads/HO/';
	    $config['allowed_types']	= 'jpg|jpeg|png';
    	$config['max_size']			= 2024;
    	$this->load->library('upload',$config);
        $this->upload->initialize($config);
    	if ($this->upload->do_upload('file_ktp')) {
            $data['file_ktp'] = $this->upload->data('file_name');
        }
    	
    	$config1['upload_path']		= './uploads/HO/';
	    $config1['allowed_types']	= 'jpg|jpeg|png';
    	$config1['max_size']		= 2024;
    	$this->load->library('upload',$config1);
    	$this->load->initialize($config1);
    	if ($this->upload->do_upload('file_akte')) {
            $data['file_akte'] =  $this->upload->data('file_name');
        }
        $config2['upload_path']		= './uploads/HO/';
	    $config2['allowed_types']	= 'jpg|jpeg|png';
    	$config2['max_size']			= 2024;
    	$this->load->library('upload',$config);
        $this->upload->initialize($config2);
    	if ($this->upload->do_upload('file_bukti_tanah')) {
            $data['file_bukti_tanah'] = $this->upload->data('file_name');
        }
    	
    	$config3['upload_path']		= './uploads/HO/';
	    $config3['allowed_types']	= 'jpg|jpeg|png';
    	$config3['max_size']		= 2024;
    	$this->load->library('upload',$config3);
    	$this->load->initialize($config1);
    	if ($this->upload->do_upload('file_imb')) {
            $data['file_imb'] =  $this->upload->data('file_name');
        }
        $config4['upload_path']		= './uploads/HO/';
	    $config4['allowed_types']	= 'jpg|jpeg|png';
    	$config4['max_size']			= 2024;
    	$this->load->library('upload',$config4);
        $this->upload->initialize($config4);
    	if ($this->upload->do_upload('file_sppl')) {
            $data['file_sppl'] = $this->upload->data('file_name');
        }
        $config5['upload_path']     = './uploads/HO/';
        $config5['allowed_types']   = 'jpg|jpeg|png';
        $config5['max_size']            = 2024;
        $this->load->library('upload',$config4);
        $this->upload->initialize($config4);
        if ($this->upload->do_upload('file_skdu')) {
            $data['file_skdu'] = $this->upload->data('file_name');
        }
        $config6['upload_path']     = './uploads/HO/';
        $config6['allowed_types']   = 'jpg|jpeg|png';
        $config6['max_size']            = 2024;
        $this->load->library('upload',$config4);
        $this->upload->initialize($config4);
        if ($this->upload->do_upload('foto_denah')) {
            $data['foto_denah'] = $this->upload->data('file_name');
        }
        $config7['upload_path']     = './uploads/HO/';
        $config7['allowed_types']   = 'jpg|jpeg|png';
        $config7['max_size']            = 2024;
        $this->load->library('upload',$config4);
        $this->upload->initialize($config4);
        if ($this->upload->do_upload('foto_depan')) {
            $data['foto_depan'] = $this->upload->data('file_name');
        }
        $config8['upload_path']     = './uploads/HO/';
        $config8['allowed_types']   = 'jpg|jpeg|png';
        $config8['max_size']            = 2024;
        $this->load->library('upload',$config4);
        $this->upload->initialize($config4);
        if ($this->upload->do_upload('file_pbb')) {
            $data['file_pbb'] = $this->upload->data('file_name');
        }
        $config9['upload_path']     = './uploads/HO/';
        $config9['allowed_types']   = 'jpg|jpeg|png';
        $config9['max_size']            = 2024;
        $this->load->library('upload',$config4);
        $this->upload->initialize($config4);
        if ($this->upload->do_upload('file_persetujuan')) {
            $data['file_persetujuan'] = $this->upload->data('file_name');
        }
        
    	
    	
        
    	
        $tb='siho';
        $this->load->model('imb_model');
        $this->imb_model->tambah_data($data,$tb);
        redirect('form_ho/data_user/'.$nik);
    	}
	


}
